from time_utils import to_minutes


class QuoteRepository:
    def __init__(self, quotes):
        self._quotes = list(quotes)

    def latest_prices(self, as_of):
        cutoff = to_minutes(as_of)
        latest_by_symbol = {}

        for quote in self._quotes:
            if to_minutes(quote["time"]) > cutoff:
                continue

            symbol = quote["symbol"]
            current = latest_by_symbol.get(symbol)

            if current is None or quote["time"] > current["time"]:
                latest_by_symbol[symbol] = quote

        return {
            symbol: quote["price"]
            for symbol, quote in latest_by_symbol.items()
        }
